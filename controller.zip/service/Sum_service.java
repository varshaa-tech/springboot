package com.example.NEW.service;

import com.example.NEW.model.Sum_entity;
import com.example.NEW.repository.Sum_repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Sum_service {
    @Autowired
    private Sum_repository sumRepository;
    public Sum_entity addNumber(int a,int b){
        Sum_entity sum_entity=new Sum_entity(a,b);
        return sumRepository.save(sum_entity);
    }
}
