package com.example.NEW.model;

import jakarta.persistence.*;

@Entity
@Table(name = "SUM_OF_NUMBER")
public class Sum_entity {

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getSum() {
        return sum;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private int a;
    private int b;
    private int sum;
    public Sum_entity(){}

    public Sum_entity(int a,int b){
        this.a=a;
        this.b=b;
        this.sum=a+b;
    }
}
