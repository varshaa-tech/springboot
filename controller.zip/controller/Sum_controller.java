package com.example.NEW.controller;

import com.example.NEW.model.Sum_entity;
import com.example.NEW.repository.Sum_repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sum")
public class Sum_controller {
    private final Sum_repository sumRepository;

    public Sum_controller(Sum_repository sumRepository){
        this.sumRepository=sumRepository;
    }
    @RestController
    public class yourcontroller{
        @GetMapping("/add")
        public Sum_entity addnumber(@RequestParam int a,@RequestParam int b){
            Sum_entity sum_entity=new Sum_entity(a,b);
            return sumRepository.save(sum_entity);
        }
    }

}

