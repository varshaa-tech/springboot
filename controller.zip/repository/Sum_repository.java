package com.example.NEW.repository;

import com.example.NEW.model.Sum_entity;
import jdk.jfr.Registered;
import org.springframework.data.jpa.repository.JpaRepository;

@Registered
public interface Sum_repository extends JpaRepository<Sum_entity,Long> {
}
